package a

func _() {
	MyFunc123()
}

func MyFunc123() {}
